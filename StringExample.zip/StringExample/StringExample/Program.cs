﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Program pg = new Program();
            //Algorithm to reverse an string Ex: Input String abcdef  process the string and produce Output: fedcba 

            Console.WriteLine("Please enter the Input String");
            var collectString = Console.ReadLine();
            try
            {
                if (string.IsNullOrEmpty(collectString))
                {
                    throw new ArgumentNullException("arg", "argcannot be null");
                }
                else
                {
                    char[] reversedArray = pg.reverseString(collectString.ToString());
                    string OutputArray = new string(reversedArray);
                    Console.WriteLine("Reversed Array = {0}", OutputArray);
                }

            }
            catch (Exception ex)
            {
                var exception = new Exception("Your message: ");
                //Display "exception" to users
                //Log "e" for further investigation 
                Console.WriteLine(exception);
                //throw exception;
            }
            Console.ReadLine();
        }

        //Function to reverse the input string
        char[] reverseString(string inputstr)
        {
            char[] originalstringArray = inputstr.ToCharArray();
            char temp = new char();
            for (int i = 0; i < originalstringArray.Length - 1; i++)
            {
                int j = i + 1;
                temp = originalstringArray[originalstringArray.Length - j];

                originalstringArray[originalstringArray.Length - j] = originalstringArray[i];
                originalstringArray[i] = temp;
            }
            return originalstringArray;
        }

        
       
//        public static bool IsAlphaNum(this string str)
//{
//    if (string.IsNullOrEmpty(str))
//        return false;

//    for (int i = 0; i < str.Length; i++)
//    {
//        if (!(char.IsLetter(str[i])) && (!(char.IsNumber(str[i]))))
//            return false;
//    }

//    return true;
//}
//Per comment :) ...

//public static bool IsAlphaNum(this string str)
//{
//    if (string.IsNullOrEmpty(str))
//        return false;

//    return (str.ToCharArray().All(c => Char.IsLetter(c) || Char.IsNumber(c)));
//}

    }
}
