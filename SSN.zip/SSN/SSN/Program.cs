﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SSN
{
    class Program
    {
        static void Main(string[] args)
        {
            //logic - Validating SSN Number SSN number format is [3 digits – 2 digits – 4 digits] Ex: 123-45-5678
           string SSNPattern = @"^\d{3}\-?\d{2}\-?\d{4}$";
           Regex regex = new Regex(SSNPattern);
           Console.WriteLine("Enter the input string to validate against SSN");
           string inputstr = Console.ReadLine();
           bool Matching = regex.IsMatch(inputstr);
           Console.WriteLine(Matching);
           Console.ReadLine();
        }
    }
}
